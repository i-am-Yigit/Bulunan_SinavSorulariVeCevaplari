#Dizi=[4,6,3,"Gürkan",2,1,"İnci"] adlı diziyi [6,5,4,3,2,1] şeklinde çıktı alabilecek hale getiren komutları yazınız. (30P)

Dizi=[4,6,3,"Gürkan",2,1,"İnci"]
Dizi.pop(3)
Dizi.pop(5)
Dizi.sort(reverse=True)
print(Dizi)
