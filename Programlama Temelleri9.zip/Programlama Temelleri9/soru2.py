#Dizi=["t","o","p","h","a","n","e","M","t","a","l"] Yukarıdaki dizide; 
#kaç tane a harfi olduğunu bulan komutu yazınız
#h harfinin indis numarasını getiren komutu yazınız.
#Ekran çıktısı olarak M t a üreten komutu yazınız.
#Print(Dizi[3:6]) komutu ne çıktı üretir yazınız. (40p)

Dizi=["t","o","p","h","a","n","e","M","t","a","l"]

#1
print(Dizi.count('a'))
#
print('')
#
#2
print(Dizi.index('h'))
#
print('')
#
#3
print(Dizi[7],Dizi[8],Dizi[9])
#
print('')
#
#4
#['h','a','n']
print(Dizi[3:6])
