#Elemanları sırasıyla 10,20,30 olan diziyi 10,10,30 olarak değiştiriniz.(10p)

dizi=['10','20','30']
dizi[1]=10
print(dizi)

#Cevap: dizi[1]=10