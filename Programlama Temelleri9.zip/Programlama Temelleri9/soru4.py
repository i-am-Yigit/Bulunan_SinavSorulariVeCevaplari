#True
Dizi=["t","o","p","h","a","n","e","M","t","a","l"]
print("p" in Dizi)
