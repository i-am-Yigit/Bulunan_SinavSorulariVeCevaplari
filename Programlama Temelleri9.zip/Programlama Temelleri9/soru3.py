#Cevap:['Ahmet','Mehmet','Derya','Jale']
Dizi2=["Ahmet","Mehmet","Derya"]
Dizi2.append("Jale")
print(Dizi2)
